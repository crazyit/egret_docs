class TestView extends egret.DisplayObjectContainer {
    public constructor() {
        super();
        this.view = new egret.DisplayObjectContainer();
        this.init();
    }

    protected view: egret.DisplayObjectContainer;
    protected testView: egret.DisplayObjectContainer;
    private init(): void {
        let back: Button = new Button("Back Menu");
        back.x = (Context.stageWidth - back.width) / 2;
        back.y = 10;
        this.addChild(back);
        back.addEventListener("CHAGE_STAGE", this.change_scene, this);
    }
    private change_scene(evt: egret.Event): void {
        this.dispose();
        egret.error('change_scene');
        //Main.backMenu();
    }

    public start(): void {
        this.view = new egret.DisplayObjectContainer();
        this.view.y = 50;
        this.addChild(this.view);
        this.testView = new egret.DisplayObjectContainer();
        this.testView.y = 200;
        this.addChild(this.testView);
    }

    protected dispose(): void {
        this.view.removeChildren();
        this.removeChild(this.view);
        this.view = null;
        this.parent.removeChild(this)
    }
}
