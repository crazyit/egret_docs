class TestSprite extends egret.DisplayObjectContainer {
    constructor() {
        super();
        this.once(egret.Event.ADDED_TO_STAGE,this.onAdd,this)
        
    }
    protected testView:egret.DisplayObjectContainer;
    protected testEUI:eui.UILayer;
    // protected back:Button;
    protected info:egret.TextField;
    protected onAdd():void{
        let bg = new egret.Shape();
        bg.graphics.beginFill(0x888888);
        bg.touchEnabled = true;
        bg.graphics.drawRect(0,0,this.stage.stageWidth,this.stage.stageHeight);
        this.addChild(bg);

        let testEUI = new eui.UILayer();
        this.testEUI = testEUI;
        this.addChild(testEUI)

        let testView = new egret.DisplayObjectContainer();
        this.testView = testView;
        this.addChild(testView);

        

        /// 提示信息
        let info = new egret.TextField;
        info.size = 28;
        info.textAlign = egret.HorizontalAlign.CENTER;
        info.lineSpacing = 6;
        info.multiline = true;
        info.x = this.stage.stageWidth/2 - info.width/2;
        info.y = 60;
        info.width = this.stage.stageWidth;
        this.info = info;
        this.addChild( info );

        let back: Button = new Button("返回");
        back.x = (Context.stageWidth - back.width) / 2;
        back.y = 10;
        this.addChild(back);
        // this.back = back;
        back.addEventListener(egret.TouchEvent.TOUCH_TAP,this.dispose,this)
    }
    protected setInfo(value:string):void{
        if(!this.stage){
            return
        }
        this.info.text = value;
        this.info.x = this.stage.stageWidth/2 - this.info.width/2;
    }
    protected dispose():void{
        this.removeChildren();
        this.parent.removeChild(this);
    }
}
