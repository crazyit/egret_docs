class Menu extends egret.Sprite {

    public constructor(title: string) {
        super();

        /*
        this.graphics.beginFill(0x535353);
        this.graphics.drawRect(0,0,Context.stageWidth, Context.stageHeight);
        this.graphics.endFill();
        */

        this.graphics.lineStyle(2, 0x282828);
        this.graphics.moveTo(0, 35);
        this.graphics.lineTo(Context.stageWidth, 35);
        this.graphics.endFill();

        this.graphics.lineStyle(2, 0x6a6a6a);
        this.graphics.moveTo(0, 37);
        this.graphics.lineTo(Context.stageWidth, 37);
        this.graphics.endFill();

        this.drawText(title);
        this.addChild(this.textF);
    }

    private textF: egret.TextField;
    private drawText(label: string): void {
        if (this.textF == null) {
            let text: egret.TextField = new egret.TextField();
            text.text = label;
            text.width = Context.stageWidth
            text.height = 35;
            text.size = 22;
            text.verticalAlign = egret.VerticalAlign.MIDDLE;
            text.textAlign = egret.HorizontalAlign.CENTER;
            this.textF = text;
            this.textF.strokeColor = 0x292b2f;
        }
    }

    private viewNum: number = 0;
    public addTestView(label: string, scene: TestView): void {
        let btn: Button = new Button(label);
        btn.testView = scene;
        if (this.viewNum % 2 == 0) {
            btn.x = 10;
        } else {
            btn.x = (Context.stageWidth - 30) / 2 + 20;
        }
        btn.y = 48 + Math.floor(this.viewNum / 2) * 47;

        this.addChild(btn);
        btn.addEventListener("CHAGE_STAGE", this.change_scene, this);
        this.viewNum++;
    }
    private change_scene(evt: egret.Event): void {
        let parent: egret.DisplayObjectContainer = this.parent;
        this.parent.removeChild(this);
        parent.addChild((evt.currentTarget as Button).testView);
        (evt.currentTarget as Button).testView.start();
    }

    public addTestFunc(label: string, callback: Function, target: Object): void {
        let btn: Button = new Button(label);
        
        // btn.x = (Context.stageWidth - 30) / 2 + 20;
        // btn.y = 48 + this.viewNum* 47;
        if (this.viewNum % 2 == 0) {
            btn.x = 10;
        } else {
            btn.x = (Context.stageWidth - 30) / 2 + 20;
        }
        btn.y = 48 + Math.floor(this.viewNum / 2) * 47;

        this.addChild(btn);
        btn.addEventListener("CHAGE_STAGE", callback, target);
        this.viewNum++;
    }
}
