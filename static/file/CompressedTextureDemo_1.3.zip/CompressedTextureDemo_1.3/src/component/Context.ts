class Context {
    static stageWidth: number = 0;
    static stageHeight: number = 0;
    static stage;
    public static init(_stage: egret.Stage): void {
        Context.stage = _stage;
        Context.stageWidth = _stage.stageWidth;
        Context.stageHeight = _stage.stageHeight;
    }
}
