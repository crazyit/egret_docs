class S8_1_Lable extends TestSprite {
    constructor() {
        super();      
        
    }
    protected onAdd():void{
        super.onAdd()

         /*** 本示例关键代码段开始 ***/
         var label:eui.Label = new eui.Label();
         label.text = "Label 是可以呈示一行或多行统一格式文本的 UI 组件,要显示的文本由 text 属性确定";
         //设置颜色等文本属性
         label.textColor = 0xff0000;
         label.size = 30;
         label.lineSpacing = 12;
         label.width = this.stage.stageWidth;
        //  label.y = 300;
         label.textAlign = egret.HorizontalAlign.JUSTIFY;
         /*** 本示例关键代码段结束 ***/
         
         this.testEUI.addChild(label);
         label.verticalCenter = 0;
         label.horizontalCenter = 0;

        
    }
}
