class S8_6_Checkbox extends TestSprite {
    constructor() {
        super();      
    }
    private _icon:egret.Shape;
    protected onAdd():void{
        super.onAdd()
        this.setInfo("点击按钮切换状态")
        ///设置Group,用于给按钮布局，具体可参看布局示例。
        var group = new eui.Group();
        group.width = this.stage.stageWidth;
        group.height = this.stage.stageHeight;
        this.testEUI.addChild(group);

        var layout = new eui.VerticalLayout();
        layout.gap = 30;
        layout.verticalAlign = egret.VerticalAlign.MIDDLE;
        layout.horizontalAlign = egret.HorizontalAlign.CENTER;
        group.layout = layout;

        ///单选按钮组
        var radioGroup:eui.RadioButtonGroup = new eui.RadioButtonGroup();

        /*** 本示例关键代码段开始 ***/
        var radio1:eui.RadioButton = new eui.RadioButton();
        radio1.label = "选项组1: A";
        ///设置单选按钮所属组件，同一组件内的只能选择一个单选按钮组
        radio1.group = radioGroup;
        radio1.value = "1-A";
        // 
        
        radio1.addEventListener(egret.Event.CHANGE,this.onChange,this);
        radio1.addEventListener(egret.Event.COMPLETE,()=>{
            (radio1.labelDisplay as eui.Label).textColor = 0x000000;
        },this)
        group.addChild(radio1);

        var radio2:eui.RadioButton = new eui.RadioButton();
        radio2.label = "选项组1: B";
        radio2.group = radioGroup;
        radio2.value = "1-B";
        radio2.addEventListener(egret.Event.CHANGE,this.onChange,this);
        radio2.addEventListener(egret.Event.COMPLETE,()=>{
            (radio2.labelDisplay as eui.Label).textColor = 0x000000;
        },this)
        group.addChild(radio2);

        var radio3:eui.RadioButton = new eui.RadioButton();
        radio3.label = "选项组1: C";
        radio3.group = radioGroup;
        radio3.value = "1-C";
        radio3.addEventListener(egret.Event.CHANGE,this.onChange,this);
        radio3.addEventListener(egret.Event.COMPLETE,()=>{
            (radio3.labelDisplay as eui.Label).textColor = 0x000000;
        },this)
        group.addChild(radio3);

        var radio4:eui.RadioButton = new eui.RadioButton();
        radio4.label = "选项组2: D";
        radio4.value = "2-D";
        ///通过设置 groupName 修改单选按钮所属组
        radio4.groupName = "Group2";
        radio4.addEventListener(egret.Event.CHANGE,this.onChange,this);
        radio4.addEventListener(egret.Event.COMPLETE,()=>{
            (radio4.labelDisplay as eui.Label).textColor = 0x000000;
        },this)
        group.addChild(radio4);

        var radio5:eui.RadioButton = new eui.RadioButton();
        radio5.label = "选项组2: E";
        radio5.value = "2-E";
        radio5.groupName = "Group2";
        radio5.addEventListener(egret.Event.CHANGE,this.onChange,this);
        radio5.addEventListener(egret.Event.COMPLETE,()=>{
            (radio5.labelDisplay as eui.Label).textColor = 0x000000;
        },this)
        group.addChild(radio5);
    }
    private onChange(e:egret.Event){
        var radioButton = <eui.RadioButton>e.target;
        this.setInfo("选择" + radioButton.value)
        
    }
}
