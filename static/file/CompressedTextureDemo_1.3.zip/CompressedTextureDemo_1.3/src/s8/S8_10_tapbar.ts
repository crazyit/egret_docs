class S8_10_tapbar extends TestSprite {
    constructor() {
        super();      
    }
    private _tabBar;
    private _viewStack;
    private _closeButton
    protected onAdd():void{
        super.onAdd()
        this.setInfo("列表测试")
        
        var tabBar = new eui.TabBar();
        tabBar.y = 200;
        var vLayout: eui.VerticalLayout = new eui.VerticalLayout();
        vLayout.gap = 0;
        vLayout.horizontalAlign = egret.HorizontalAlign.LEFT;
        tabBar.layout = vLayout;
        var viewStack = new eui.ViewStack();
        viewStack.x = 220;
        viewStack.y = 200;
        tabBar.selectedIndex = -1;
        var itemName=["强化", "进阶", "副本", "转生", "神气", "国战"];

        for (let i: number = 0; i < itemName.length; i++ ) {
            var group: eui.Group = new eui.Group();
            group.name = itemName[i];
            var text: eui.Label = new eui.Label();
            text.text = "您已打开" + itemName[i] + "面板";
            text.textColor = 0x00000;
            group.addChild(text);
            viewStack.addChild(group);
        }
        tabBar.dataProvider = viewStack;

        this._tabBar = tabBar;
        this._viewStack = viewStack;

        this.testEUI.addChild(this._tabBar);
        /*** 本示例关键代码段结束 ***/

        this._tabBar.addEventListener( egret.TouchEvent.TOUCH_TAP, this.changeTab, this );
        this._closeButton = new eui.Button();
        this._closeButton.width = 150;
        this._closeButton.height = 50;
        this._closeButton.x = 480;
        this._closeButton.y = 510;
        this._closeButton.label = "关闭";
        this._closeButton.addEventListener( egret.TouchEvent.TOUCH_TAP, this.close, this );
    }
    private changeTab (evt: egret.TouchEvent) {
        this.testEUI.addChild(this._viewStack);
        this.testEUI.addChild(this._closeButton);
    }
    private close (evt: egret.TouchEvent) {
        this.testEUI.removeChild(this._viewStack);
        this.testEUI.removeChild(this._closeButton);
    }
}
