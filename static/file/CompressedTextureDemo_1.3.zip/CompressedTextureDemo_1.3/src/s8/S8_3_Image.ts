class S8_3_Image extends TestSprite {
    constructor() {
        super();      
    }
    private _source:Array<string> =  [ "resource/assets/bird.png",
        "resource/assets/hero.png",
        "resource/assets/weapon.png"
    ];
    private idx:number;
    private image:eui.Image;
    protected onAdd():void{
        super.onAdd()
        this.setInfo("点击舞台，更换图片");

        let img = new eui.Image();
        img.horizontalCenter =0 ;
        img.verticalCenter = 0;
        this.image = img;
        this.testEUI.addChild(img);
        this.idx = 0;

        this.changeImage();
        this.addEventListener(egret.TouchEvent.TOUCH_TAP,this.changeImage,this);
    }
    private changeImage(){
        // console.log(this._source[this.idx])
        this.image.source = this._source[this.idx];

        this.idx +=1;
        let len = this._source.length;
        if(this.idx>=len){
            this.idx=0;
        }

    }
}
