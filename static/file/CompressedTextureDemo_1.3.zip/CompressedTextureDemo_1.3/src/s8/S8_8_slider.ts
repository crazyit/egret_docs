class S8_8_slider extends TestSprite {
    constructor() {
        super();      
    }
    ///水平滑动选择器
    private _hSlider:eui.HSlider;
    ///垂直滑动选择器
    private _vSlider:eui.VSlider;
    ///显示水平滑动选择器的值
    private _hLabel:eui.Label;
    protected onAdd():void{
        super.onAdd()
        this.setInfo("点击按钮切换状态")
        ///设置Group,用于给按钮布局，具体可参看布局示例。
        // var group = new eui.Group();
        // group.width = this.stage.stageWidth;
        // group.height = this.stage.stageHeight;
        // this.testEUI.addChild(group);

        // var layout = new eui.VerticalLayout();
        // layout.gap = 30;
        // layout.verticalAlign = egret.VerticalAlign.MIDDLE;
        // layout.horizontalAlign = egret.HorizontalAlign.CENTER;
        // group.layout = layout;

        /*** 本示例关键代码段开始 ***/         
        var hSlilder:eui.HSlider = new eui.HSlider();
        hSlilder.width = 280;
        hSlilder.maximum = 100;
        hSlilder.horizontalCenter = 0;
        hSlilder.verticalCenter = 0;
        ///监听 CHANGE 事件
        hSlilder.addEventListener(egret.Event.CHANGE,this.onHSliderChange,this);

        this._hSlider = hSlilder;
        this.testEUI.addChild(this._hSlider);
        
        var vSlider:eui.VSlider = new eui.VSlider();
        vSlider.height = 200;
        vSlider.verticalCenter = 0;
        vSlider.horizontalCenter = 240;
        ///通过 minimum 属性设置最小值。
        vSlider.minimum = 100;
        ///通过 maximum 属性设置最大值。
        vSlider.maximum = 1000;
        ///通过 snapInterval 属性设置增加的有效值。
        vSlider.snapInterval = 100;
        ///监听 CHANGE 事件
        vSlider.addEventListener(egret.Event.CHANGE,this.onVSLiderChange,this);
        this._vSlider = vSlider;
        this.testEUI.addChild(this._vSlider);

        /*** 本示例关键代码段结束 ***/
        
        var hLabel:eui.Label = new eui.Label();
        
        hLabel.textColor = 0x1122cc;
        hLabel.size = 18;
        hLabel.verticalCenter = 30; 
        hLabel.horizontalCenter = 0;
        hLabel.text = "Value:" + hSlilder.pendingValue;
        this._hLabel = hLabel;
        this.testEUI.addChild(this._hLabel);
        
        var vLabel:eui.Label = new eui.Label();
        vLabel.textColor = 0x1122cc;
        vLabel.size = 18;
        vLabel.horizontalCenter = 240;
        vLabel.verticalCenter = -120;
        vLabel.text = "Max:1000"; 
        this.testEUI.addChild(vLabel);
    }
    private onHSliderChange(e:egret.Event) {
        var slilder = <eui.HSlider>e.target;
        var hSlider = this._hSlider;
        var hLabel = this._hLabel;
        ///通过 pendingValue 属性获得滑块当前值。
        hLabel.text = "Value:" + hSlider.pendingValue;
    }

    private onVSLiderChange(e:egret.Event) {
        var slilder = <eui.HSlider>e.target;
        var hSlider = this._hSlider;
        
        var scale = slilder.pendingValue / hSlider.maximum;
        hSlider.maximum = slilder.pendingValue;
        hSlider.value *= scale;

        this.setInfo("设置水平滑块的最大值为" + slilder.pendingValue)
    }
}
