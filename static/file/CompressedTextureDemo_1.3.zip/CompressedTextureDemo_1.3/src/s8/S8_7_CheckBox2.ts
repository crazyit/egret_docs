class S8_7_CheckBox2 extends TestSprite {
    constructor() {
        super();
    }
    private _icon: egret.Shape;
    protected onAdd(): void {
        super.onAdd()
        this.setInfo("点击按钮切换状态")
        ///设置Group,用于给按钮布局，具体可参看布局示例。
        var group = new eui.Group();
        group.width = this.stage.stageWidth;
        group.height = this.stage.stageHeight;
        this.testEUI.addChild(group);

        var layout = new eui.VerticalLayout();
        layout.gap = 30;
        layout.verticalAlign = egret.VerticalAlign.MIDDLE;
        layout.horizontalAlign = egret.HorizontalAlign.CENTER;
        group.layout = layout;
        group.horizontalCenter = 0;

        this.setInfo("当前选中条目：4 5 6");

        /*** 本示例关键代码段开始 ***/
        var checkBox1: eui.CheckBox = new eui.CheckBox();
        ///设置按钮的标签
        checkBox1.label = "1.正常状态";
        checkBox1.addEventListener(egret.Event.CHANGE, this.onChange, this);
        checkBox1.addEventListener(egret.Event.COMPLETE, () => {
            (checkBox1.labelDisplay as eui.Label).textColor = 0x000000;
        }, this)
        group.addChild(checkBox1);

        var checkBox2: eui.CheckBox = new eui.CheckBox();
        checkBox2.label = "2.按下状态";
        ///显式设置按钮组件的视图状态为 down。
        checkBox2.currentState = "down";
        checkBox2.addEventListener(egret.Event.CHANGE, this.onChange, this);
        checkBox2.addEventListener(egret.Event.COMPLETE, () => {
            (checkBox2.labelDisplay as eui.Label).textColor = 0x000000;
        }, this)
        group.addChild(checkBox2);

        var checkBox3: eui.CheckBox = new eui.CheckBox();
        checkBox3.label = "3.禁用状态";
        ///显式设置按钮组件的视图状态为 disabled
        checkBox3.currentState = "disabled";
        checkBox3.addEventListener(egret.Event.CHANGE, this.onChange, this);
        checkBox3.addEventListener(egret.Event.COMPLETE, () => {
            (checkBox3.labelDisplay as eui.Label).textColor = 0x000000;
        }, this)
        group.addChild(checkBox3);

        var checkBox4: eui.CheckBox = new eui.CheckBox();
        checkBox4.label = "4.抬起并选中状态";
        ///显式设置按钮组件的视图状态为 upAndSelected
        checkBox4.currentState = "upAndSelected";
        checkBox4.addEventListener(egret.Event.CHANGE, this.onChange, this);
        checkBox4.addEventListener(egret.Event.COMPLETE, () => {
            (checkBox4.labelDisplay as eui.Label).textColor = 0x000000;
        }, this)
        group.addChild(checkBox4);

        var checkBox5: eui.CheckBox = new eui.CheckBox();
        checkBox5.label = "5.按下并选中状态";
        ///显式设置按钮组件的视图状态为 downAndSelected
        checkBox5.currentState = "downAndSelected";
        checkBox5.addEventListener(egret.Event.CHANGE, this.onChange, this);
        checkBox5.addEventListener(egret.Event.COMPLETE, () => {
            (checkBox5.labelDisplay as eui.Label).textColor = 0x000000;
        }, this)
        group.addChild(checkBox5);

        var checkBox6: eui.CheckBox = new eui.CheckBox();
        checkBox6.label = "6.禁用并选中状态";
        ///显式设置按钮组件的视图状态为 downAndSelected
        checkBox6.currentState = "disabledAndSelected";
        checkBox6.addEventListener(egret.Event.CHANGE, this.onChange, this);
        checkBox6.addEventListener(egret.Event.COMPLETE, () => {
            (checkBox1.labelDisplay as eui.Label).textColor = 0x000000;
        }, this)
        group.addChild(checkBox6);
    }
    private onChange(event: egret.TouchEvent) {
        var checkBox: eui.CheckBox = <eui.CheckBox>event.target;


        if (checkBox.currentState === "disabled" || checkBox.currentState === "disabledAndSelected") {
            this.setInfo("禁用状态，无法选择")
        } else {
            ///获得当前复选框的标签并显示出来
            this.setInfo("状态改变：" + checkBox.label)
            ///取消显示设置复选框的状态，由内部的 getCurrentState() 决定。
            checkBox.currentState = null;
        }

    }
}
