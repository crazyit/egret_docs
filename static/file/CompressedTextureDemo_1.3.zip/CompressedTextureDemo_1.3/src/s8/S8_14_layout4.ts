class S8_14_layout4 extends TestSprite {
    constructor() {
        super();      
    }
    private _grpLayout:eui.Group;
    private _iAlignMode:number;
    protected onAdd():void{
        super.onAdd()
        /// 创建容器，在其中进行布局
        this._grpLayout = new eui.Group();
        this._grpLayout.bottom = 200;
        this._grpLayout.horizontalCenter = 0;

        this.testEUI.addChild( this._grpLayout );
        this._grpLayout.width = LenItem.WBASE_OUTLINE;
        this._grpLayout.height = LenItem.HBASE_OUTLINE;

        /// 绘制矩形用于显示 _grpLayout 的轮廓
        var iFillColor:number = 0x000000;
        var outline:egret.Shape = new egret.Shape;
        outline.graphics.clear();
        outline.graphics.lineStyle( 3, iFillColor );
        outline.graphics.beginFill( 0x000000, 0 );
        outline.graphics.drawRect( 0, 0, LenItem.WBASE_OUTLINE, LenItem.HBASE_OUTLINE ); /// 注意该轮廓为Shape，没有参与布局，所以其尺寸并不能影响容器的尺寸
        outline.graphics.endFill();
        this._grpLayout.addChild( outline );

        /*** 本示例关键代码段开始 ***/

        for ( var i:number = 1; i <= 18; ++i ) {
            var btn:eui.Button = new eui.Button();
            btn.label = "按钮" + ( i < 10 ? "0" : "" ) + i;
            this._grpLayout.addChild( btn );
        }

        var tLayout:eui.TileLayout = new eui.TileLayout();
        tLayout.paddingTop = 30;
        tLayout.paddingLeft = 30;
        tLayout.paddingRight = 30;
        tLayout.paddingBottom = 30;
        this._grpLayout.layout = tLayout;

        this._iAlignMode = AlignMode.WH;
        tLayout.columnAlign = eui.ColumnAlign.JUSTIFY_USING_GAP;
        tLayout.rowAlign = eui.RowAlign.JUSTIFY_USING_GAP;

        /// 创建事件，在轻触时随机改变间隙
        this.stage.addEventListener( egret.TouchEvent.TOUCH_TAP, ( evt:egret.TouchEvent )=> {
            this.prudRdmElemSize( tLayout );
        }, this );

        /*** 本示例关键代码段结束 ***/

        this.info.touchEnabled = true;
        this.info.addEventListener( egret.TouchEvent.TOUCH_TAP, ( evt:egret.TouchEvent )=> {
            evt.stopImmediatePropagation();
            this._iAlignMode = ( this._iAlignMode + 1 ) % 2;        /// 在序列元素间切换模式 
            switch ( this._iAlignMode ) {
                case AlignMode.GAP:
                    tLayout.columnAlign = eui.ColumnAlign.JUSTIFY_USING_GAP;
                    tLayout.rowAlign = eui.RowAlign.JUSTIFY_USING_GAP;
                    break;
                case AlignMode.WH:
                    tLayout.columnAlign = eui.ColumnAlign.JUSTIFY_USING_WIDTH;
                    tLayout.rowAlign = eui.RowAlign.JUSTIFY_USING_HEIGHT;
                    break;
            }
            this.updateInfo( tLayout );
        }, this );

        this.prudRdmElemSize( tLayout  );
    }
    /// 生成随机的元素宽高
    private prudRdmElemSize( tLayout:eui.TileLayout ){
        tLayout.horizontalGap = LenItem.WBASE_GAP + LenItem.WRANGE_GAP * Math.random();
        tLayout.verticalGap = LenItem.HBASE_GAP + LenItem.HRANGE_GAP * Math.random();
        this.updateInfo( tLayout );
    }

    private updateInfo( tLayout:eui.TileLayout ) {
        let text =
            "轻触UI区域随机调整水平与垂直间隙" +
            "\n轻触本文字区调整行列对齐方式" +
            "\n当前行列布局对齐：" + ( this._iAlignMode == 0 
                ? "调整间隙"
                    +  "\n调整间隙将会不会改变布局元素尺寸"
                : "调整元素宽高"
                    +  "\n调整后水平/垂直间隙：" + (tLayout.horizontalGap << 0) + "/" + (tLayout.verticalGap << 0) 
            );
        this.setInfo(text)
    }
    
}
class LenItem {
    public static WBASE_OUTLINE:number = 580;
    public static HBASE_OUTLINE:number = 650;

    public static WBASE_GAP:number = 10;
    public static WRANGE_GAP:number = 100;

    public static HBASE_GAP:number = 10;
    public static HRANGE_GAP:number = 30;
}

class AlignMode {
    public static GAP:number = 0;
    public static WH:number = 1;
}