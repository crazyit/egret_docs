class S8_9_List extends TestSprite {
    constructor() {
        super();      
    }
    ///水平滑动选择器
    private _hSlider:eui.HSlider;
    ///垂直滑动选择器
    private _vSlider:eui.VSlider;
    ///显示水平滑动选择器的值
    private _hLabel:eui.Label;
    protected onAdd():void{
        super.onAdd()
        this.setInfo("列表测试")
        
        var listGroup = new eui.List();
        listGroup.width = 300;
        listGroup.dataProvider = new eui.ArrayCollection(["关卡1-1初出茅庐", "关卡1-2一战成名", "关卡1-3历尽艰辛", 
        "关卡1-4百年好合", "关卡1-5刻苦锻炼", "关卡1-6天下第一", "关卡1-7暮然回首", "关卡1-8孤独求败", 
        "关卡1-9成宗立派", "关卡1-10香火绵延"]);

        var listScroller = new eui.Scroller();
        listScroller.width = 300;
        listScroller.height = 300;
        listScroller.x = this.stage.stageWidth/2 - listGroup.width/2;
        listScroller.y = 200;

        listScroller.viewport = listGroup;
        this.testEUI.addChild(listScroller);
    }
}
