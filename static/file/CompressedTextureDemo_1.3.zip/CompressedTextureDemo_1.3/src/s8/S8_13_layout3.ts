class S8_13_layout3 extends TestSprite {
    constructor() {
        super();      
    }
    private _grpLayout:eui.Group;
    protected onAdd():void{
        super.onAdd()
        this._grpLayout = new eui.Group();
        this._grpLayout.horizontalCenter = 0;
        this._grpLayout.verticalCenter = 0;
        
        this.testEUI.addChild( this._grpLayout );
        this._grpLayout.width = Len.WBASE;
        this._grpLayout.height = Len.HBASE;
        
        /// 绘制矩形用于显示 _grpLayout 的轮廓
        var iFillColor:number = 0x000000;
        var outline:egret.Shape = new egret.Shape;
        outline.graphics.lineStyle( 3, iFillColor );
        outline.graphics.beginFill(0x000000,0);
        outline.graphics.drawRect( 0,0,Len.WBASE, Len.HBASE ); /// 注意该轮廓为Shape，没有参与布局，所以其尺寸并不能影响容器的尺寸
        outline.graphics.endFill();
        this._grpLayout.addChild( outline );


        /*** 本示例关键代码段开始 ***/
        this._grpLayout.layout = new eui.BasicLayout();

        var btn:eui.Button = new eui.Button();
        btn.label = "按钮一";
        btn.horizontalCenter = 0;
        btn.verticalCenter = 0;
        this._grpLayout.addChild( btn );

        var btn:eui.Button = new eui.Button();
        btn.label = "按钮二";
        btn.top = 20;
        btn.left = 20;
        this._grpLayout.addChild( btn );

        var btn:eui.Button = new eui.Button();
        btn.label = "按钮三";
        btn.right = 20;
        btn.bottom = 20;
        this._grpLayout.addChild( btn );

        var hLayout:eui.VerticalLayout = new eui.VerticalLayout();
        hLayout.gap = 10;
        hLayout.paddingTop = 30;
        hLayout.horizontalAlign = egret.HorizontalAlign.CENTER;
        this._grpLayout.layout = hLayout;
        /*** 本示例关键代码段结束 ***/
        
        /// 创建事件，在轻触时随机改变容器及轮廓的尺寸
        this.stage.addEventListener( egret.TouchEvent.TOUCH_TAP, ()=>{
            var w:number = Len.WBASE + Len.WRANGE * Math.random();
            var h:number = Len.HBASE + Len.HRANGE * Math.random();
            outline.graphics.clear();
            outline.graphics.lineStyle( 3, iFillColor );
            outline.graphics.beginFill(0x000000,0);
            outline.graphics.drawRect( 0,0,w, h ); 
            outline.graphics.endFill();
            this._grpLayout.width = w;
            this._grpLayout.height = h;
        }, this );

        this.setInfo("轻触舞台随机调整布局容器的尺寸")
    }
    
}
