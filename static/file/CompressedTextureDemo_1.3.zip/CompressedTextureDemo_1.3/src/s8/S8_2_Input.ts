class S8_2_Input extends TestSprite {
    constructor() {
        super();      
        
    }
     ///输入文本
     private _nameInput:eui.TextInput;
     ///输入密码文本
     private _passInput:eui.TextInput;
     ///显示文本
     private _label:eui.Label;
    protected onAdd():void{
        super.onAdd()

        var background:eui.Rect = new eui.Rect(300,300,0xcccccc);
        background.verticalCenter = 0;
        background.horizontalCenter = 0;
        this.testEUI.addChild(background);

        var nameInput:eui.TextInput = new eui.TextInput();
        nameInput.prompt = "输入文本:";
        nameInput.horizontalCenter = 0;
        nameInput.verticalCenter = -150;
        this._nameInput = nameInput;
        this.testEUI.addChild( this._nameInput);

        var passInput:eui.TextInput = new eui.TextInput();
        passInput.prompt = "密码文本:";
        ///设置显示为密码文本
        passInput.displayAsPassword = true;
        passInput.horizontalCenter = 0;
        passInput.verticalCenter = -108;
        this._passInput = passInput;
        this.testEUI.addChild(this._passInput);

        var label:eui.Label = new eui.Label();
        label.size = 20;
        label.text = "已输入:";
        label.width = 280;
        label.height = 160;
        label.verticalCenter = 0;
        label.horizontalCenter = 0;
        this._label = label
        this.testEUI.addChild(this._label);

        nameInput.addEventListener(egret.Event.CHANGE,this.onChange,this);

        passInput.addEventListener(egret.Event.CHANGE,this.onChange,this);
        
    }
     ///显示输入的文本
    private onChange(e:egret.Event) {
        var label = this._label;
        var nameInput = this._nameInput;
        var passInput = this._passInput;

        label.text = "已输入:" + "\r\n" +
            "输入文本:" + nameInput.text + "\r\n" +
            "密码文本:" + passInput.text;
    }
}
