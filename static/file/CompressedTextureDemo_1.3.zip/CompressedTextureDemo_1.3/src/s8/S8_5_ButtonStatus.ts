class S8_5_ButtonStatus extends TestSprite {
    constructor() {
        super();      
    }
    private _icon:egret.Shape;
    protected onAdd():void{
        super.onAdd()
        this.setInfo("点击按钮切换状态")
        ///设置Group,用于给按钮布局，具体可参看布局示例。
        var group = new eui.Group();
        group.width = this.stage.stageWidth;
        group.height = this.stage.stageHeight;
        this.testEUI.addChild(group);

        var layout = new eui.VerticalLayout();
        layout.gap = 30;
        layout.verticalAlign = egret.VerticalAlign.MIDDLE;
        layout.horizontalAlign = egret.HorizontalAlign.CENTER;
        group.layout = layout;

        /*** 本示例关键代码段开始 ***/
        var radio1:eui.ToggleButton = new eui.ToggleButton();
        radio1.label = "按钮 A";
        radio1.addEventListener(egret.Event.CHANGE,this.onChange,this);
        group.addChild(radio1);

        var radio2:eui.ToggleButton = new eui.ToggleButton();
        radio2.label = "按钮 B";
        radio2.addEventListener(egret.Event.CHANGE,this.onChange,this);
        group.addChild(radio2);

        var radio3:eui.ToggleButton = new eui.ToggleButton();
        radio3.label = "按钮 C";
        radio3.addEventListener(egret.Event.CHANGE,this.onChange,this);
        group.addChild(radio3);
    }
    private onChange(e:egret.Event){
        var radioButton = <eui.ToggleButton>e.target;

        var text = "当前状态";
        ///获取当前单选按钮的状态
        radioButton.selected ?  text += ":选中" : text += ":未选中";
        this.setInfo(text)
        
    }
}
