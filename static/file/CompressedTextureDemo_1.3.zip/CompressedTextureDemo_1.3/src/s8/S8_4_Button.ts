class S8_4_Button extends TestSprite {
    constructor() {
        super();      
    }
    private _icon:egret.Shape;
    protected onAdd():void{
        super.onAdd()

        var group = new eui.Group();
        group.width = this.stage.stageWidth;
        group.height = this.stage.stageHeight;
        this.testEUI.addChild(group);

        var layout = new eui.VerticalLayout();
        layout.gap = 30;
        layout.verticalAlign = egret.VerticalAlign.MIDDLE;
        layout.horizontalAlign = egret.HorizontalAlign.CENTER;
        group.layout = layout;

        ///绘制icon，并保存。
        var icon:egret.Shape = new egret.Shape();
        icon.graphics.beginFill(0xcc2211);
        icon.graphics.drawCircle(12,12,6);
        icon.graphics.endFill();
        this._icon = icon;

        var renderTexture:egret.RenderTexture = new egret.RenderTexture();
        renderTexture.drawToTexture(icon);

        
        /*** 本示例关键代码段开始 ***/
        var btn1 = new eui.Button();
        ///设置按钮的标签
        btn1.label = "按钮";
        btn1.icon = renderTexture;
        btn1.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onTouch,this);
        group.addChild(btn1);

        var btn2 = new eui.Button();
        btn2.label = "按下状态";
        ///显式设置按钮组件的视图状态为 down。可通过设置 currentState 为 null 来取消显示设置，设置为 null 之后视图状态将由内部的 getCurrentState() 决定。
        btn2.currentState = "down";
        btn2.addEventListener(egret.TouchEvent.TOUCH_BEGIN,this.onTouch,this);
        btn2.addEventListener(egret.TouchEvent.TOUCH_END,this.onTouch,this);
        group.addChild(btn2);

        var btn3 = new eui.Button();
        btn3.label = "禁用状态";
        ///显式设置按钮组件的视图状态为 disabled。
        btn3.currentState = "disabled";
        btn3.addEventListener(egret.TouchEvent.TOUCH_BEGIN,this.onTouch,this);
        btn3.addEventListener(egret.TouchEvent.TOUCH_END,this.onTouch,this);
        group.addChild(btn3);

        var btn4 = new eui.Button();
        btn4.label = "正常状态";
        btn4.addEventListener(egret.TouchEvent.TOUCH_TAP,this.onTouch,this);
        group.addChild(btn4);

        ///获得按钮的标签对象，并设置其值。需要注意类型转换。
        var label:eui.Label = <eui.Label>btn4.labelDisplay;
        label.size = 28;
        label.border = true;
        label.textColor = 0xcccccc;
        label.borderColor = 0xcccccc;
        label.text = "自定义按钮文字样式";
       

    }
    ///处理按钮的触摸事件回调
    private onTouch(event:egret.TouchEvent) {
        ///获得当前按钮
        var btn:eui.Button = <eui.Button>event.target;
        ///获得按钮icon，并绘转换为纹理
        var renderTexture:egret.RenderTexture = new egret.RenderTexture();
        renderTexture.drawToTexture(this._icon);

        switch (event.type) {
            case egret.TouchEvent.TOUCH_BEGIN:
                //设置按钮的 icon
                btn.icon = renderTexture;
                break;
            case egret.TouchEvent.TOUCH_END:
                //取消按钮的 icon
                btn.icon = null;
                break;
            default :
                break;
        }

    }
}
