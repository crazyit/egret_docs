//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////

class SceneFiltersTest extends DemoScene {
    constructor() {
        super();
    }
    protected onAddToStage(event: egret.Event): void {

        const sw = this.stage.stageWidth;
        const sh = this.stage.stageHeight;
        /////////////    
        const hero1 = this.createBitmapByName("hero_png");
        hero1.name = 'DropShadowFilter_Hero';
        this.addChild(hero1);
        {
            //投影滤镜
            const distance: number = 6;           /// 阴影的偏移距离，以像素为单位
            const angle: number = 45;              /// 阴影的角度，0 到 360 度
            const color: number = 0x000000;        /// 阴影的颜色，不包含透明度
            const alpha: number = 0.7;             /// 光晕的颜色透明度，是对 color 参数的透明度设定
            const blurX: number = 16;              /// 水平模糊量。有效值为 0 到 255.0（浮点）
            const blurY: number = 16;              /// 垂直模糊量。有效值为 0 到 255.0（浮点）
            const strength: number = 0.65;                /// 压印的强度，值越大，压印的颜色越深，而且阴影与背景之间的对比度也越强。有效值为 0 到 255。暂未实现
            const quality: number = egret.BitmapFilterQuality.LOW;              /// 应用滤镜的次数，暂无实现
            const inner: boolean = false;            /// 指定发光是否为内侧发光
            const knockout: boolean = false;            /// 指定对象是否具有挖空效果
            const dropShadowFilter: egret.DropShadowFilter = new egret.DropShadowFilter(distance, angle, color, alpha, blurX, blurY, strength, quality, inner, knockout);
            hero1.filters = [dropShadowFilter];
            hero1.x = 10;
            hero1.y = 10;
        }
        /////////////
        const hero2 = this.createBitmapByName("hero_png");
        hero2.name = 'GlowFilter_Hero';
        this.addChild(hero2);
        {
            //发光滤镜
            const color: number = 0x33CCFF;        /// 光晕的颜色，十六进制，不包含透明度
            const alpha: number = 0.8;             /// 光晕的颜色透明度，是对 color 参数的透明度设定。有效值为 0.0 到 1.0。例如，0.8 设置透明度值为 80%。
            const blurX: number = 35;              /// 水平模糊量。有效值为 0 到 255.0（浮点）
            const blurY: number = 35;              /// 垂直模糊量。有效值为 0 到 255.0（浮点）
            const strength: number = 2;            /// 压印的强度，值越大，压印的颜色越深，而且发光与背景之间的对比度也越强。有效值为 0 到 255。暂未实现
            const quality: number = egret.BitmapFilterQuality.HIGH;        /// 应用滤镜的次数，建议用 BitmapFilterQuality 类的常量来体现
            const inner: boolean = false;            /// 指定发光是否为内侧发光，暂未实现
            const knockout: boolean = false;            /// 指定对象是否具有挖空效果，暂未实现
            const glowFilter: egret.GlowFilter = new egret.GlowFilter(color, alpha, blurX, blurY, strength, quality, inner, knockout);
            hero2.filters = [glowFilter];
            hero2.x = hero1.x;
            hero2.y = 10 + hero1.height;
        }
        /////////////
        const hero3 = this.createBitmapByName("hero_png");
        hero3.name = 'BlurFilter_Hero';
        this.addChild(hero3);   
        {
            //模糊滤镜  
            const blurFliter = new egret.BlurFilter(2, 2);
            hero3.filters = [blurFliter.blurXFilter, blurFliter.blurYFilter];
            hero3.x = hero1.x + 200;
            hero3.y = 10 + hero1.height;
        }

        //
        const button = new egret.TextField;
        this.addChild(button);
        button.text = 'SceneFiltersTest';
        button.size = 30;
        button.touchEnabled = true;
        button.x = this.stage.stageWidth - button.width;
        button.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            (this.parent as Main).changeToScene(new SceneDeleteTest);
        }, this);
    }

    protected onRemoveFromStage(event: egret.Event): void {
        this.removeChildren();
    }
}