//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////



class Main extends egret.DisplayObjectContainer {

    private currentScene: DemoScene = null;

    constructor() {
        super();
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
        //
        egret.ImageLoader.crossOrigin = "anonymous";
        egret.registerImplementation("eui.IAssetAdapter", new AssetAdapter());
        egret.registerImplementation("eui.IThemeAdapter", new ThemeAdapter());
    }

    private onAddToStage(event: egret.Event) {
        egret.lifecycle.addLifecycleListener((context) => {
            context.onUpdate = () => {
            }
        });
        egret.lifecycle.onPause = () => {
            egret.ticker.pause();
        }
        egret.lifecycle.onResume = () => {
            egret.ticker.resume();
        }
        this.runGame().catch(e => {
            egret.error(e);
        });
    }

    private async runGame() {
        await this.loadResource();
        this.createGameScene();
    }

    public async recoverResource(): Promise<any> {
        this.loadResource().catch(e => {
            egret.error(e);
        });
    }

    private async loadResource() {
        /*
         * 我想忽略掉activity_bg_png，这个资源不用压缩纹理
         */
        const ignoreResource = (imageResourceInfo: RES.ResourceInfo): boolean => {
            return imageResourceInfo && imageResourceInfo.name === 'activity_bg_png';
        };
        try {
            RES.processor.map('pack.etc1.ktx', new PackETC1KTXProcessor());
            RES.processor.map('image', new CompressTextureProcessor(ignoreResource, true));
            await RES.loadConfig("resource/default.res.json", "resource/");
            await RES.loadGroup("preload", 0);
        }
        catch (e) {
            egret.error(e);
        }
    }

    private onEnterFrame(advancedTime: number): void {
        if (advancedTime > 1000 / 30) {
            advancedTime = 1000 / 30;
        }
        const dtMs = advancedTime;
        const dtSec = advancedTime / 1000;
        if (this.currentScene) {
            this.currentScene.updateScene(dtMs, dtSec);
        }
    }

    /**
     * 创建游戏场景
     * Create a game scene
     */
    private createGameScene(): void {
        //首次启动场景就是etc1的
        this.changeToScene(new SceneAutoLoadCompressedTexture); // SceneAutoLoadCompressedTexture 
        egret.Ticker.getInstance().register(this.onEnterFrame, this);
    }

    public changeToScene(to: DemoScene): void {
        if (this.currentScene && this.currentScene.parent === this) {
            this.removeChild(this.currentScene);
            this.currentScene = null;
        }
        this.currentScene = to;
        this.addChild(this.currentScene);
    }
}