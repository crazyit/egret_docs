//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////


class PackETC1KTXProcessor implements RES.processor.Processor {

    /**
     * 
     */
    public onLoadStart(host: RES.ProcessHost, resource: RES.ResourceInfo): Promise<any> {
        egret.log('PackETC1KTXProcessor = ' + resource.root + resource.url);
        return host.load(resource, 'bin').then((data) => {
            //
            if (!data) {
                console.warn('PackETC1KTXProcessor data is null:' + resource.root + resource.url);
                return null;
            }

            //
            const databuffer = data;
            const u32View = new Uint32Array(databuffer);
            const head = u32View[0];
            const colorBufferSize = u32View[1];
            const alphaBufferSize = u32View[2];
            egret.log(resource.root + resource.url + ', file info______');
            egret.log('head = ' + head);
            egret.log('color buffer size = ' + colorBufferSize);
            egret.log('alpha mask buffer size = ' + alphaBufferSize);
            let offset = /*type*/4 + /*color size*/4 + /*alpha size*/4;

            //构建colorbuffer
            const u8View = new Uint8Array(databuffer);
            const colorBuffer = new Uint8Array(u8View.slice(offset, offset + colorBufferSize));
            egret.log('colorBuffer.byteLength = ' + colorBuffer.byteLength);

            //构建alphabuffer
            offset += colorBufferSize;
            const alphaBuffer = alphaBufferSize > 0 ? new Uint8Array(u8View.slice(offset, offset + alphaBufferSize)) : null;
            if (alphaBuffer) {
                egret.log('alphaBuffer = ' + alphaBuffer.byteLength);
            }
            else {
                egret.log(resource.root + resource.url + ': no alpha');
            }

            //创建颜色的纹理
            let colorTexture: egret.Texture = null;
            if (colorBuffer) {
                const bufferData = new ArrayBuffer(colorBuffer.byteLength);
                const view = new Uint8Array(bufferData);
                view.set(colorBuffer);
                colorTexture = this.createCompressedTexture(host, resource, bufferData);
            }
            else {
                egret.error('?');
            }

            //创建alpha遮罩的纹理
            let alphaMaskTexture: egret.Texture = null;
            if (alphaBuffer){
                const bufferData = new ArrayBuffer(alphaBuffer.byteLength);
                const view = new Uint8Array(bufferData);
                view.set(alphaBuffer);
                alphaMaskTexture = this.createCompressedTexture(host, resource, bufferData);   
            }

            //绑定对应的color和alpha
            if (colorTexture 
                && colorTexture.$bitmapData
                && alphaMaskTexture 
                && alphaMaskTexture.$bitmapData) {
                colorTexture.$bitmapData.etcAlphaMask = alphaMaskTexture.$bitmapData;
            }

            //
            host.save(resource as RES.ResourceInfo, colorTexture);

            //
            return colorTexture;
        }, function (e) {
            host.remove(resource);
            throw e;
        });
    }
    /*
    * 未来可以封装函数，在引擎
    */
    public createCompressedTexture(host: RES.ProcessHost, resource: RES.ResourceInfo, data: ArrayBuffer): egret.Texture {
        //
        if (!data) {
            egret.error('ktx:' + resource.root + resource.url + ' is null');
            return null;
        }
        //
        const ktx = new egret.KTXContainer(data, 1);
        if (ktx.isInvalid) {
            egret.error('ktx:' + resource.root + resource.url + ' is invalid');
            return null;
        }
        //
        const bitmapData = new egret.BitmapData(data);
        bitmapData.debugCompressedTextureURL = resource.root + resource.url;
        bitmapData.format = 'ktx';
        ktx.uploadLevels(bitmapData, false);
        //
        const texture = new egret.Texture();
        texture._setBitmapData(<egret.BitmapData>bitmapData);
        const r = host.resourceConfig.getResource(resource.name);
        if (r && r.scale9grid) {
            const list: Array<string> = r.scale9grid.split(",");
            texture["scale9Grid"] = new egret.Rectangle(parseInt(list[0]), parseInt(list[1]), parseInt(list[2]), parseInt(list[3]));
        }
        return texture;
    }

    public onRemoveStart(host: RES.ProcessHost, resource: RES.ResourceInfo): void {
        const colorTexture = host.get(resource) as egret.Texture;
        if (colorTexture) {
            if (colorTexture.$bitmapData) {
                let etcAlphaMask = colorTexture.$bitmapData.etcAlphaMask;
                if (etcAlphaMask) {
                    etcAlphaMask.$dispose();
                    colorTexture.$bitmapData.etcAlphaMask = etcAlphaMask = null;
                }
            }
            colorTexture.dispose();
        }
    }
}
