//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////

class DemoScene extends egret.DisplayObjectContainer {

    protected dragonBonesFactory1: dragonBones.EgretFactory = null;
    protected dragonBonesFactory2: dragonBones.EgretFactory = null;
    protected movieClipFactory1: egret.MovieClipDataFactory = null;
    protected movieClipFactory2: egret.MovieClipDataFactory = null;

    constructor() {
        super();
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
        this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStage, this);
    }

    protected onAddToStage(event: egret.Event): void {
    }

    protected onRemoveFromStage(event: egret.Event): void {
    }

    protected createBitmapByName(name: string): egret.Bitmap {
        const result = new egret.Bitmap();
        result.name = name;
        const texture: egret.Texture = RES.getRes(name);
        result.texture = texture;
        return result;
    }

    protected createDragonBones(factory: dragonBones.EgretFactory, dragonName: string, animationName: string, specialSuffix: string): dragonBones.EgretArmatureDisplay {
        const key = dragonName + animationName || '';
        const skeData: any = RES.getRes(`${dragonName}_ske_json`);
        const texData: any = RES.getRes(`${dragonName}_tex_json`);
        let texture: egret.Texture = RES.getRes(`${dragonName}_tex_png`);
        if (specialSuffix !== '') {
            texture = RES.getRes(dragonName + specialSuffix);
        }
        factory.parseDragonBonesData(skeData);
        factory.parseTextureAtlasData(texData, texture);
        const armatureName: string = animationName || "anim";
        const display: dragonBones.EgretArmatureDisplay = factory.buildArmatureDisplay(armatureName);
        display.name = key;
        return display;
    }

    public updateScene(dtMs: number, dtSec: number): void {

    }
}
