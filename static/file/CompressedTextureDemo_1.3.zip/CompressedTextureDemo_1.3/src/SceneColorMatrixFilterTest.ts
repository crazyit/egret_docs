//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////

class SceneColorMatrixFilterTest extends DemoScene {
    constructor() {
        super();
    }
    protected onAddToStage(event: egret.Event): void {
        //
        const icon1 = this.createBitmapByName("hero_png");
        this.addChild(icon1);
        icon1.x = this.stage.stageWidth / 2 - icon1.width / 2 - 100;
        icon1.y = this.stage.stageHeight / 2 - icon1.height / 2;
        const colorMatrix = [
            0.3, 0.6, 0, 0, 0,
            0.3, 0.6, 0, 0, 0,
            0.3, 0.6, 0, 0, 0,
            0, 0, 0, 1, 0
        ];
        const colorFlilter1 = new egret.ColorMatrixFilter(colorMatrix);
        icon1.filters = [colorFlilter1];
        //
        const icon2 = this.createBitmapByName("hero_png");
        this.addChild(icon2);
        icon2.x = this.stage.stageWidth / 2 - icon2.width / 2 + 100;
        icon2.y = this.stage.stageHeight / 2 - icon2.height / 2;
        const whiteColorMatrix = [
            1, 0, 0, 0, 100,
            1, 1, 0, 0, 100,
            1, 0, 1, 0, 100,
            1, 0, 0, 1, 0,
        ];
        const colorFlilter2 = new egret.ColorMatrixFilter(whiteColorMatrix);
        icon2.filters = [colorFlilter2];
        //
        const button = new egret.TextField;
        this.addChild(button);
        button.text = 'SceneColorMatrixFilterTest';
        button.size = 30;
        button.touchEnabled = true;
        button.x = this.stage.stageWidth - button.width;
        button.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            (this.parent as Main).changeToScene(new SceneFiltersTest);
        }, this);
    }

    protected onRemoveFromStage(event: egret.Event): void {
        this.removeChildren();
    }
}