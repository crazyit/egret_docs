//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////

class SceneETC1EUITest extends DemoScene {

    constructor() {
        super();
    }

    protected onAddToStage(event: egret.Event): void {
        //
        this.start();

        //
        const button = new egret.TextField;
        this.addChild(button);
        button.text = 'SceneETC1EUITest';
        button.size = 30;
        button.touchEnabled = true;
        button.x = this.stage.stageWidth - button.width;
        button.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            (this.parent as Main).changeToScene(new SceneColorMatrixFilterTest);
        }, this);
    }

    protected onRemoveFromStage(event: egret.Event): void {
        this.removeChildren();
    }

    private start(): void {
        Context.init(this.stage);
        this.loadConfig();
    }

    private async loadConfig() {
        new eui.Theme("resource/default.thm.json", this.stage);
        this.loadEnd();
    }

    private loadEnd(): void {
        const menu = new Menu("EUI 皮肤解析");
        this.addChild(menu);
        menu.addTestFunc("1.显示文本", this.s8_1_Lable, this);
        menu.addTestFunc("2.输入文本", this.s8_2_Input, this);
        menu.addTestFunc("3.图片", this.s8_3_Image, this);
        menu.addTestFunc("4.按钮", this.s8_4_Button, this);
        menu.addTestFunc("5.按钮状态切换", this.s8_5_ButtonStatus, this);
        menu.addTestFunc("6.单选按钮", this.s8_6_Checkbox, this);
        menu.addTestFunc("7.复选框", this.s8_7_CheckBox2, this);
        menu.addTestFunc("8.滑动选择器", this.s8_8_slider, this);
        menu.addTestFunc("9.列表", this.s8_9_List, this);
        menu.addTestFunc("10.选项卡", this.s8_10_tapbar, this);
        menu.addTestFunc("11.基本布局", this.s8_11_layout, this);
        menu.addTestFunc("12.水平布局", this.s8_12_layout2, this);
        menu.addTestFunc("13.垂直布局", this.s8_13_layout3, this);
        menu.addTestFunc("14.网格布局", this.s8_14_layout4, this);
        menu.addTestFunc("15.自定义布局", this.s8_15_layout5, this);
    }
    
    private s8_1_Lable(): void {
        let s = new S8_1_Lable();
        this.addChild(s);
    }
    private s8_2_Input(): void {
        let s = new S8_2_Input();
        this.addChild(s);
    }
    private s8_3_Image(): void {
        let s = new S8_3_Image();
        this.addChild(s);
    }
    private s8_4_Button(): void {
        let s = new S8_4_Button();
        this.addChild(s);
    }
    private s8_5_ButtonStatus(): void {
        let s = new S8_5_ButtonStatus();
        this.addChild(s);
    }
    private s8_6_Checkbox(): void {
        let s = new S8_6_Checkbox();
        this.addChild(s);
    }
    private s8_7_CheckBox2(): void {
        let s = new S8_7_CheckBox2();
        this.addChild(s);
    }
    private s8_8_slider(): void {
        let s = new S8_8_slider();
        this.addChild(s);
    }
    private s8_9_List(): void {
        let s = new S8_9_List();
        this.addChild(s);
    }
    private s8_10_tapbar(): void {
        let s = new S8_10_tapbar();
        this.addChild(s);
    }
    private s8_11_layout(): void {
        let s = new S8_11_layout();
        this.addChild(s);
    }
    private s8_12_layout2(): void {
        let s = new S8_12_layout2();
        this.addChild(s);
    }
    private s8_13_layout3(): void {
        let s = new S8_13_layout3();
        this.addChild(s);
    }
    private s8_14_layout4(): void {
        let s = new S8_14_layout4();
        this.addChild(s);
    }
    private s8_15_layout5(): void {
        let s = new S8_15_layout5();
        this.addChild(s);
    }
    
}