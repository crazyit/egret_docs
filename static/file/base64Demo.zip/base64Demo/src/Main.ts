//////////////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014-present, Egret Technology.
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Egret nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY EGRET AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
//  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
//  IN NO EVENT SHALL EGRET AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;LOSS OF USE, DATA,
//  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
//  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////////////////

class Main extends egret.DisplayObjectContainer {



    public constructor() {
        super();
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStage, this);
    }

    private onAddToStage(event: egret.Event) {

        egret.lifecycle.addLifecycleListener((context) => {
            // custom lifecycle plugin

            context.onUpdate = () => {

            }
        })

        egret.lifecycle.onPause = () => {
            egret.ticker.pause();
        }

        egret.lifecycle.onResume = () => {
            egret.ticker.resume();
        }

        this.runGame().catch(e => {
            console.log(e);
        })



    }

    private async runGame() {
        await this.loadResource()
        this.createGameScene();
        const result = await RES.getResAsync("description_json")
        this.startAnimation(result);
        await platform.login();
        const userInfo = await platform.getUserInfo();
        console.log(userInfo);

    }

    private async loadResource() {
        try {
            const loadingView = new LoadingUI();
            this.stage.addChild(loadingView);
            await RES.loadConfig("resource/default.res.json", "resource/");
            await RES.loadGroup("preload", 0, loadingView);
            this.stage.removeChild(loadingView);
        }
        catch (e) {
            console.error(e);
        }
    }

    private textfield: egret.TextField;

    /**
     * 创建游戏场景
     * Create a game scene
     */
    private createGameScene() {
        let sky = this.createBitmapByName("bg_jpg");
        this.addChild(sky);
        let stageW = this.stage.stageWidth;
        let stageH = this.stage.stageHeight;
        sky.width = stageW;
        sky.height = stageH;

        let topMask = new egret.Shape();
        topMask.graphics.beginFill(0x000000, 0.5);
        topMask.graphics.drawRect(0, 0, stageW, 172);
        topMask.graphics.endFill();
        topMask.y = 33;
        this.addChild(topMask);

        // let icon = this.createBitmapByName("egret_icon_png");
        // this.addChild(icon);
        // icon.x = 26;
        // icon.y = 33;

        // let rt:egret.RenderTexture = new egret.RenderTexture();
        // rt.drawToTexture(icon,new egret.Rectangle(0,0,icon.width,icon.height));
        // let base64 = rt.toDataURL("image/png")
        // console.log(base64)

        let str64 = "iVBORw0KGgoAAAANSUhEUgAAAHMAAACsCAYAAABIK5McAAAdtUlEQVR4Xu2dC7i813TG11uqCEUk7hqkUeISt9JGXIImQoQIqkjqlpJQ1CVxl5C6pFVCSJQ0Lk3UJUQkSERFI0jFJVTStAiqUqSta2hLX89vnrXn2ef7z5zzzZyZOTPfzH6e8yT/c7755tv7/fbea639rncpVq0zI6DO9GTVkViB2aGXYAXmCswOjUCHurKamSswOzQCHerKamauwOzQCHSoK6uZuQKzQyPQoa6sZuYKzA6NQIe6spqZKzA7NAId6spczEzbvxURfxIR94+I346Ia0XETyPimxHxiYj4cEScJel/OjT2E+/KloJp+0oRcXhEvCQi3h0RL4+If4mIK0fEbSLioRFxaERcJyJ+FBEnR8Qxkv554iPRgRtuGZi2b5Tg3CvH8VaSLmmOqe0dI+LtOWu/FxHbR8Rf8AJI+r8OYDCxLmwJmLb3ioi/jQiA+seIYJk9XtKRg3pm+yoR8cGcrW+LiMdHxDci4gBJ35nYaCz4jWYKZoJyREQ8N6J/MP7FiPjviHiGpC8NG0/b14uIf82//2FEAPxNI+JBkj634DhM5PFnAmaCeGBE/FEaNKdHxEXDDBrbGEHflfTjupe2j46I50TEv0XEHhHxkYi4cUQ8WNI5ExmRBb7JVMG0jeFySETcLiLeGxEfkPSLjcbL9lUjYs+0bM+XxFIctu8SEZ/Nz7NvnpD/Zhl+tKRTNrp3l/8+FTBt3yoiHsf4Y7xIumjcQbR9v4i4a0S8Kpfmn0cEVvAPc1buHRGAyHdhDR/R5oUZ93nm+XMTA9M299onf9jb3ioJd2LTzfadIuLZEcFS/Z/ph3Lf/SWdavstEfGE/CL23adJwj9dqjZJMH83Iq4ZEedI+v9Jj6Lt10XED9LvvG7eHwv4ENvXiIgv5LJcvvofIuK4XNp/Nunnmcf7TQzMaXfO9u9HBAARBdouv+/7EXFDSb+0vVtEfCYi2G/rxvWfTLAJSHw3AxAXSPrJtJ97lvdfJDB3iAjAa7b7Svp7fml7vzS0fn3Add+OiE+lf3tuRPyYl2CWgz3t71okMK+d/mhzTJ4q6Q3ll7bvkYARiKgbs5BlF4Psn6Y9sFtx/0UC82YRcemAQTpMEm5Kv9m+WhpEj4kILGvChFi5BOw72xYJTGK4gwIDT5L0151FaISOLRKYr42Ipw/o2wMlfWiEPnf20rkG0/ZvRsTuxF/TJRkExJ0lfb6zCI3QsbkEM40YZuEDB7gaze7hmvzHCH3u7KVzBabt34gILNMSzdlo4AnEX6drLsZGnR7297kB0za+IXsfsdg27TyCAZI4Tlu16kxxywfD9p9HxPNbPghx169HxMclvaPlZzp/2VzMzCR0EXLjsHlQI1Lz4vQXWVoJAFwmaZDf2XnQ5nqZtc1SCTOv8IHq5yVof5Ckk5YWpZYd3/KZmQy9NyWvpzzP5RHBueVNImKbCE/Lvi3dZfMAJgfPp3L6UY0+eycHzRdwMC2Jg+dV22AE5gHMZ0bEq6vn/HRSMF8fEX8sCZrlqrUYgXkAE2uUgHhpj4iIfdknI2JXSRe36MfqknlwTWzjLxKyo2G1EsLjdOOeMAckfW2FVLsRmIeZ+dWI2Dkf96uSdrENlxbmwB6SAHvVWozAPIAJ+QueLO1iSbvahjkA1fLJkrB0V63FCMwDmPBg4cPSyPyCUXBMnpKcK4nldtVajMA8gEn218OrZ71P7pu4K7QnSPqbFn1Z+kvmAcwXRMRRFRJn59EXhg9BA9q7IoKUBghdzFwSjvgbqX9X5IwmzEewAfbd1yRB4FqqNg9gkjMCW65uzErAeOoIaMCNhTlPEtLdEvg/JR9lGjzeEZ5rZpfOA5jMLvisNx+h16TzXZiz8uqZrgCXFquYRCLSF0r792TrbSpNYoRn27JLtxxMep7MgjMjAlZds5HigHsCAZoZjCvz2Ig4uHJp2g4g4UHolidLIvbbqTYXYCagUCKflICSFARocHu+mIz1X8tkJPbXG6yDAsm3Jya7/b9yX+WzdfuSJP7WqTY3YK43qpnKB52EoPx67a8i4gVdnHVt3rq5BtM2M/ClEfHEFqHHp0h6Y5tOd/WauQXTNpboK6okofUwOErSi7oKUtt+zSWYtp8SEce27AT+537jnHnahqbCPv3KLmSEzR2YthF0QsyJ/w5qgMcRGY3EWyRnCBaM1WzDz2UZv4+kQVlmY913Kz40j2A+Od2HQeOBlQtfCPeC9lxJpMeP1FIA49LCt7UNv2inBPR/R7rZHF08j2Ci91NmXnOoUBchMsRMot1MErO4dbNNGJCgAz8kHX3MNgEHEnU/LQnZt4Vs8whmfYrSHFSC8ih7EQL8pSSiRyM128+IiNfkh/rMP9u3jAj0hJ4j6fiRbjonF88jmG+F+zNkfAi+w3wvibTXHdX5t42oFFp9pRGoh9Fwme0Dkn9ENjY83oVq8wgmQhc93Z8W7TajytLYfmFEvKxx7z6d0zaBh0dGxO03Y1i1ePaJXzJ3YNJD2yxzuAzDGsFz5Nf2lXTWKKPSWGbLR0+XRNog383Mh+kAa/4B47g8ozzPJK+dVzAJuJNPwiwd1DjuwkX5jCRmUus2BEyOzXasrFv2ZXhIR0v6y9Y33+IL5xLMnCGQolluywF1c6hQxby1pEI5aTWUtpuH4eVz966FoGzfNyLOiIi7L4rQ4tyCmYAiIMyxFxp8zYaLwux5gyRcllbNNrHeQaG/V0hak4WWxhL75x0lzb0w1FyDmYDCGiBvE9HgZsPq3UlS06AZCqxtAg4EJprtbEl/UP8y82DYk1HgJFY8123uwUxAUcWEGA2LoG4jJxXZfk9EPKy6CVROjK3vSGreH4OIkxv8T4hlrVeArUB9IcBMQFHoIuyGinRp6M7eaRQXwjYqXUi30YjF3joi0ERgLK4yiC9km1RD9ug7SCIePJdtYcBMQOH2kEj0qGo0CcPh5OP8b9hsk6CLQBTtg5L2s42+EIChj4DY4jbNNsJRhA9rWuiG3zfLCxYKzHUA/XiqQa9Rjh4CCsKIiA3Tni/pFbahmcArWg9MBBYxuF4+r5lpCwfmOoAy0JxrsvQObCllWgO+J3Lgtj/AZyFfN6XE6xvZJsGJvZvo0EgB/lnM0IUEswIUmTUqKZTGueYTJQHOoKUSn7WATZCdjDOOvCCB7SBpw/GwDbseSicvwsR1dTcD+oYPv5mbz+KzSS9hP0NDqDSsTs464db2m+3bRsSX8xcXSrqDbTSHUJL+pqSylw599KqKA8vtyGep0xyThQczZ+muaRjduTFY+Kfvz7QF1KI55ioBAwwh9PhemfTOV7XVFEp2ApUc7iaJ5X0uWifATEA52/yzlJgBuFHaV3BX1tsvGzOc7wJE+Lh3aWtJj/JA41zbGTBL523j+BN/pXpDU+J70BhxRkpcdqREI9tkq30sIt4kaVBEaRw8NvWZzoFZgYooPz4hxeFgJgxKfSDlgXooIwFZfQe1WjjQfqgklvMtbZ0Fs7EsMkOJ+iB+UWYRwYEbUPUIAcZxyjnahgRGxUCShG+71eqaSwFmNZPIZ6FkBuD2Y7G2Sbcfi/dT0VDOkDSMiDaTGbtsYFJ3BT8TA4m+X5WyjbbRIXphOeayDbdoYAy2OYuT2UdKIgfaB0vCzdmStlRgptUL5QTFLwylnSV93TY6RLD93pnXIDQF7RKBqX6zzTEcPiwVBQnY95ptQoGEBIkuQcrekjKQywjm38EeSAZDryZKcmnfIgkxRsCB/Xc+9ToL+68622Tvhc3XB8w2Lgq5n3eMiPdIYm+eeVtGMGvGfF/8wjZL5d5F9tQ2VEtmJyUeARgWApq4L5OEXOqaZvve6N/mL7ekCMAyglmH9PrAZHE4qhAReAA8mAWARzwX2gpWKxbwLnWSUZKnL2cG20aL4cFZfwXrttWx3KSm8DKCyZIIG48g+zskodEHeOybJPQi4H+F7etnAJ6ZefskZj9eEntj2SuhtLB3EuBHr4jzVqoZMa7EbglezKwtHZgJHJEbIjh90aj0Gck/OVASrAIA5jpIZbAcYCNwON0v5mob5U0UUdg/KWbOfkrqA2WUOY1hdpbSyuUF2E4SfunE27KCSXD9cNwUSf2aYbbJMvuCJPY/wEQEo1QzOksShVf7zTbcoDvkMgyPF/+VUxh8WWbphyRRzoN7Mdac7lCpFx7SxNuygknt65PTRcHX7KXx2b4sxS9wLy5JVwSRKALrfSvVNsRoXBxOTn4oaYfqKI08lltU+TLUwz4t0yKguzBbp3IOuqxg4kKUKkUYNF8lUJAEL8YEkQuUqAEYIvQDIuKNksjo5nfQTtD3K6HB8hLwWRj20DkxmJid30oSGhV3sZ57S/g02rKCiRBU2bceJOl024emAcQ414YRugok+B5bc2dtI0JFOQ72SvZMAhEchsN0uNw2/ix7J41APtwjZvyGBdTHBXopwczZxTJJCA6wyAzDCi20y49WVm4pKNff//LzfJZ7UOH+IU0AGqwG/kzUiNk8tbbMYJLHQmISFizOfqlej3HyqTLwtguYcGyvX7LCbJfirMdIIoF3m1b5nfyNJN6pJiEtM5hlL6xBIJVvF0CWhOHD/oirUcDCeIGVwO8LmO+UVPN4+/ezzSkKaf00fFuW2e9Na2ouM5hvrrQRyvjiS76oPvmw/bQ0drhmjfatbfZB9t5bDCJP24ZvRKJSaSdKqtmEE8V1mcF8XUQ0k4EGZYIRCYJagojFqyU9uyBgG4sYy5gKEJTtWFN/xXatP9+b0JnigGU78bbMYBbKRxlUlkN8wm0K4tjePyKwTrFyi9IJSy2hPnxN2mm8HJJwRfgbuvNEfzCsyDXF9aH1UiImjmQLPbppfOeW39M2kRrchTLAPNO6RVVtw6nlzLPPmM9C5eyhRSsXtwMl6+dlGBCfEj0/ZnZdiAdGH9GjibalnJm2nxURtWU5MJ2vzUjnDCSG2w8Lpr/KCQuBdmbyKVQVrNiC75cE0WyibenAzIA68t8EDkp7lyQypMdqttGMx+olTMiYkpOCOBTuzj0lndtwU1jKsYx5jom1ZQQTlvs+EUFqAew6QDxkXEJXjUSCiu9KiiAUFPbGEi5khmJB01AyeZ+kYXpHYwG8VGDaJryGIYP7cVQecXEUhtAFsdSJtSrn83oILNouESO+46MphIxWwsQKui4NmJnOd0keSx2cnB72tR8NSn/fLKpVCaweaYz72YYnRD4M8VwOwq82STb8MoFJXBTKyD4cedmGPUBg/CRJdZXAzeLY+3wFZp8PZJvjMeTeaKQGopfAEt9zZzbblgJM2xwqY6DsXiI1tg9Jt+FxktDrm2irwOyfttiuj95wVQhcYCBN5Fis82DmXoX8C0dd/f3Jdqnbua5/OS7CVXE6fE8A+3SyDfBTCQHia26Ytj/K93cazNwXiezAwmsSmgm1/YSE21EGrO21jbgsJy5kml2UuoAHSMKdmWjrOpjwW6nJCUWk35J5R1AdbXaiNRNvqR/EC0NMlwaDj0ABFJX92yb2jvJgnQUztXvQHSgGRw0msdb3pS4BPuFU2oBTkzNhzUM7KbyjSX5xJ8G0DTWSUNozhwTOCY7D50EqZmqa7Bm7xR0hTR9jhxgtWn+UY5546xyYaWQcmUvoQEZ51rmGVQdRa6ot9WvRUrhkmvwfOtFFMCFmnTosEyuZdRSLe56kotU+VUBndfNOgZk0jZ9REWHYANqGdU5KAZp7kJU70zoDpm3CZMhwrytXmsdfBNmvPs39civekE6AmWeKUP8fQSb0egOZR1G7SmIf61RbeDAzREbqObp58FiHtgy248BTk7PIlHYG0IUG0zbWKIk9SLdsWD7DNhUS4Op8oiQHdQbJRbZmbT86czru1daQsU16OpXlWYo5w8Tv60xbyJmZlYEoJQUBufXxVSYHQUIm4bafm9kVNBcOzIyrcvqB4haHzTAHOJmAMV5OIShgQyAb9h3peLDx+OHfqHWVRrrB1Bjms35JFhFMKgLBFOdwudnIxmqG50ighUAFkBQ/JWBA0PuCZgB+1oM/6e9bODAnPQBdut8KzA6huQJzBWaHRqBDXVnNzBWYHRqBDnVlNTNXYC7+CCTh6geSfj6t3tgmOekaswpMKA9r65ogpW+/2Ooi2rZJ6llPNJ/KtmPliNgmuHBE0fuZBqC24Ro9VhIRqak3wNwmU7j61mtLIoIy85ZvNd9NOG5Y64svjfqA2e8jB7H3Rr3XsOtTqQQwEbOYeitgwivlcLduPx/3rW/71LZJf6N+JWeR21QwSMlswnc0hJXQu6ur3CIpOhbTrctgTvUNXefNRQyJEhKktq1buacI27ep19XmZVpaMG0jsABvBtlrZgqV6iiehpY5dSfhqUIqRmyXFHMq0SK6i+AfJGT2PvTNyRR+saQzU44MvVa0AlBhZkm9f5HRbgIyCMzMgua5KC+MZU4FebiyvZySZOLBWOeYjFMUGObwVk9MMOGy8nv6RQD+eEkoXvJZ9jvuSa1p5F7Qy6PfhxaJ0ZQDR+GLxCT+jno0rL9evbHmMptbByx7xoPAP+IV6NIWrSA+8zs51owr+zop9BDPHoJCpu0z8/juqDJGaVscWpZZOk/Blrpx3ndCLnVIpJAsSk4hiS+U+UXnHGBZ9gCEL0QX57yIQBoFJQ5O9e8UEYfl50gTR5weoV10XAGBBFiWWu6LNMtA67IJZhZYYzZT+hCtHc4oAQ5tgdux19tGUQT2OhnLGEpUeMfYI3OaYzN+WBkAgYNr+gQp7MOZLMu/6RdZ0OSkIDR8tKTD8/sRmQBwRCh4buRJEaugFNWFNZip4w5rkBeY6xlzMqup1NvTuM0kp7JCHZsvONnVpCJewd5rm0lDgjA1WXpjZRs9+Z8WMEnLbp66n4YWuW3qMVPzo84zpAOoanDTGkzebFLl+AIGjmt6g5O/43Ooc3yFCrG2x15mbbMKoONz81K2IlcQjsF4hs+mCP5LJPWFlWxfGTJyzsxzJO2Zz0Y/OBqjwNvzE0xexJtIYtbSJ15qbIndbaNeCSse1a2yElBig9WH/u3TAJPqRxyoP0wSs61o0JKWf5ecLGVloz5nUQLDmiePlLNXwGQCkNX2KKo9pKw457qPKWAeJWlQuXu+kLeaZQoF475OalaqQ1euBpOEGHTKa4F63uzeYGTjzUS095abBJNUcl4mZlWxyOk492em84YjFcrAlDKL/YdIMNeIONlmdTgFLbwEk5wQxCZ6LdMAmfWUaoRzZEl8X31fZL9hCW7XABPVaCRNoXj2GYS2EbLgedmaGM+bSmKpre/J73tWcTL22ZYulbSXbailqFHfsIA51ACyzdLKFwJm/+DXNtYl+0UNZq9SbHa8CB6x9yCbUjekWt69STCZ7bAGyEZuivFSh5qliRdxoObOIAPINqKIsOELmFETv2yTlEsRccDkJbqmpN0aAw/zYS9J2zfAxFtA3YvPsBKWF+TpCSIAAho00DV1PDMN8JHFxUnub68GdtoJpyOfWsAcWN4hQSlifhQX7RX/zMQc8h1RoRoGJqRkkmaeLglDg88hpsse+d5MRcfwAJS710VfGsCXTmNIsWT2QpD5MvFWUsOyJwSc+9jvpfIygoYsP7hd7Engx8zdEWGmCYDJ/ozA8H0k9UpgJH+XZ+GFOKgBZimV0atzndeT7oeNwX/h8TLDGCuAg3hW7smeeKUKTIxJthO+lzHkBbuwgMle0VujGw1rlWWSLGPYcCxd3IQZwWeQrx4IZj5IERvEAmPdZx/lTd5D0vm2MYKw6NhnmE28MPBat2kDDCD2J9IMGARkRVGhxMDihdkpC7YVLXb6wPdjeF0rIojI4J+uWZFGnJlwkLAJ8JVRyMQYQY+dslOk2182wJrFqGGfxerGcCs2B1b8JylNlfshz8lkgdPE/8MHpoxyP/iQqwTG0ecksecGYLIsDAuZMROwypgNWLC8BZjggENn4KwCJpYkArxYo30icn7uwLQoeRC05JDH7vuUqS1A2UIsYUpN9KRBmy2LwNBplvcyW6ntxdvMW88zsI+9vq6WZ5s6I0iIImiIofJmVgHbGEUfaZSBwuqGIH2W7V6JjLryu22SZbEisUaZNYwbovxYx0SqmGXoz6JiUoxAVo6eRHj+jnEsrhoT6LU15TOzxhgzDDP2Vowl9u2nNMDkOzGe+hpGrU5NWB6bkZYsA0GHyXGcioD8IFC7/rshY83Mx6ru78+2eUHYb9Fk6BmYG4JpG//q3Az34W/10rjz36+RxNu8ahMYgWTcs6VRqopAAjOfpZTEYYIVx2VFB2wVCsyh8tVX2VwXzFwm2V/Y+6D2l8Z+wxKL7vjUMo8nMD4LdQvbGG3oA9XcXvZi9v6XphGHrUL0CL7vneuY9oYzs1rrAZViohgYX6ZCwKgjlXsMkRac9YkIGeU+RDjxHm1KBRM0yPqZHPH1XYQBezR7MP71yM9qmz0OXu5YL3qGCTHs2DMvLMto9pWVktJXFNNZIz3TGsxRgRt0fVVuoh8FaXPfdGne1nhjieWy9JxnG5cJI6q/5OR9vyEJ37EYH1yDr1iqxaPJXqrRNs90sXr5LNYnka01doFtfo9bwj0xdth6iJZh3DBrcIkQjFrviLFN91tfMzMwM0AAIHwngeth9T168d3G24jpjRtABb0yOLgBLPe4NiXBlpAksw0rF7epb7bngGMpX5yqk4CH68UPUqL4xcNavz5Y9WLgTn2rqrmJC4HLQYCc5ZI0w6lJ0wx60KmDmQHmk/KNbfuWkTeCxh3OMm89UqK4NfheBUwC2gTy8XtZsvExWd5wmwAah5ryE4S+6moHdcgRF4mIFS/Bzo2HA2zCb4QNn1WHBG1jVfLZvluQyzdbz3FoC6VOHobLjcbZktoOVH3dLMAsOZEc2QzVGqgeCt4MzjU1Ke9azQT8M3JFCImxV7w9Y6/4WyxxzAhkzBhknHFCiHzfYRxZVaUrtgFzUF2S6vpttPXy5ILv5CSJPRg7goZRiLhh0WDnBSkHGN+fVnW+MkazAJNgAssgQet1U9Qr4AhpHVSFr9jw2SMBjL8VfwtlEc5aOSRgyS1sBWYVg8rJyf1YsicFZhZoK8s6x21tDTnOcdfVWxhnNs56Zq6JqbZ54AFhsFIQBmOFYyL2VeKbLLslMlUL2vM1nGYAJEdG6y6zGVgn3smSykv0lWEz0zbRHV5KLGg+gxtRZiZRMQwf3Iv+gXP2Gat0YkLBW7VnbhrMBINjLE5C6oYhxZ5JULpvteYFhBmp31XOV8sLwUCXIzFOdiilyCkJs5+ZTLiSeGvJ+VyzzNpGMIqQJcdWRL96obtqVeFw4duD6oO1eZE3c80sltkemGmJtn1W9qPdGrFIBpu9EAeaWYFGK5YsRgc+WU30QpmL4PrZ1Wl8AbP5DP1aXnnqQcCfmCkxXQyxQXsmbAnOLQeBSX95SbYn2N+2w5O4bpZgjvq8yKGtoSjaJuiMQbVRYW6OlBDt7RUDbyyz+IKc1NMIVFOxtl+YzTbLJvQPPjsOmLhRzHCscUJuM2uzBLMUcmnTOUhPKIg0wcRSxdwnZollWzdcDGYqRhH7JCf6HLk1wZyENbvezGRMWfo5s22Wp2rT97GvmRmYo1Akh5GHUyobJ5+9srl/YuWyd8IAIIx2eGE9NGbmVMHM7zohz27hJ3UnAjQO33UdMJl9N04DpM0b/HlJgL+hNdu82QZ+5tCZmd9F0IKC4ntzNtrmQSdxzSxmJix0jJbWqQ62sRQfDo+m7qRtKs/CciMIvlHD1+S7KUVxaVJGCfX1WG056NAvKbSGwbKmpcwMxtVIBlDeF1cFygrxXHSKmhyojZ59rL/PAszCBeJMlMD2Rg2rlTDaGdAxc3DglhKma9MgX0NsxudjJsOW75VpSkYdcVMoG4DNKdC+kjj87TXbMAfgy0KWIkgBOQv/s99srzsz8z4YUsxKXBzCjljNGEZTa1MHMztGIJuTjTYi8+wxWJnMiB4fKLkxzMqNGjOBn+JHMjugWvaOomwTfCesSBgOxx9uMBTIGqhS+Jv7AALi+M0TE/hQnL6w2pRC5Ns8Wx7sQ0+B1gKRizDl1NpMwJza069uvGYEVmB26IVYgbkCs0Mj0KGurGbmCswOjUCHurKamSswOzQCHerKamauwOzQCHSoK6uZuQKzQyPQoa78CuYJSTgW6lW2AAAAAElFTkSuQmCC"
        egret.BitmapData.create("base64",str64,(bitmapData)=>{
            let texture = new egret.Texture();
            texture.bitmapData = bitmapData;
            let bmp = new egret.Bitmap(texture);
            this.addChild(bmp)
        })

        let line = new egret.Shape();
        line.graphics.lineStyle(2, 0xffffff);
        line.graphics.moveTo(0, 0);
        line.graphics.lineTo(0, 117);
        line.graphics.endFill();
        line.x = 172;
        line.y = 61;
        this.addChild(line);


        let colorLabel = new egret.TextField();
        colorLabel.textColor = 0xffffff;
        colorLabel.width = stageW - 172;
        colorLabel.textAlign = "center";
        colorLabel.text = "Hello Egret";
        colorLabel.size = 24;
        colorLabel.x = 172;
        colorLabel.y = 80;
        this.addChild(colorLabel);

        let textfield = new egret.TextField();
        this.addChild(textfield);
        textfield.alpha = 0;
        textfield.width = stageW - 172;
        textfield.textAlign = egret.HorizontalAlign.CENTER;
        textfield.size = 24;
        textfield.textColor = 0xffffff;
        textfield.x = 172;
        textfield.y = 135;
        this.textfield = textfield;


    }

    /**
     * 根据name关键字创建一个Bitmap对象。name属性请参考resources/resource.json配置文件的内容。
     * Create a Bitmap object according to name keyword.As for the property of name please refer to the configuration file of resources/resource.json.
     */
    private createBitmapByName(name: string) {
        let result = new egret.Bitmap();
        let texture: egret.Texture = RES.getRes(name);
        result.texture = texture;
        return result;
    }

    /**
     * 描述文件加载成功，开始播放动画
     * Description file loading is successful, start to play the animation
     */
    private startAnimation(result: string[]) {
        let parser = new egret.HtmlTextParser();

        let textflowArr = result.map(text => parser.parse(text));
        let textfield = this.textfield;
        let count = -1;
        let change = () => {
            count++;
            if (count >= textflowArr.length) {
                count = 0;
            }
            let textFlow = textflowArr[count];

            // 切换描述内容
            // Switch to described content
            textfield.textFlow = textFlow;
            let tw = egret.Tween.get(textfield);
            tw.to({ "alpha": 1 }, 200);
            tw.wait(2000);
            tw.to({ "alpha": 0 }, 200);
            tw.call(change, this);
        };

        change();
    }
}
