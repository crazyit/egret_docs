# 小游戏联机对战引擎 MGOBE


* [对战引擎文档](https://cloud.tencent.com/product/mgobe/developer)

目前小游戏对战引擎仅支持在微信小游戏环境内使用。

您可以直接使用对战引擎的API，如 `MGOBE.Listener.init()`，但是在 Html5 环境下会报错。

您也可以使用我们封装的 API，如`egret.mogbe.Listener.init`。白鹭封装的 API，在 Html5 环境下不会报错，会在 log 中提示 `该接口只在微信小游戏下可用`