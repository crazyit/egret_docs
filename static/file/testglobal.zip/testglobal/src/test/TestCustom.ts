class TestCustom extends eui.Component {

	private id_img: eui.Image;

	public _customSource = "mbtnGoods_png" ;

	constructor() {
		super();
		this.addEventListener(eui.UIEvent.CREATION_COMPLETE, this._uiCompHandler, this);
		this.skinName = "TestCustomSkin";
	}

	private _uiCompHandler(): void {
		this.id_img.source = this._customSource;
	}
}

//自定义嵌套eui需要挂在到 window 对象
window["TestCustom"] = TestCustom;