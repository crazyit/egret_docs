class TestSkinPanel extends eui.Component {

	constructor() {
		super();
		this.addEventListener(eui.UIEvent.CREATION_COMPLETE, this._uiCompHandler, this);
		this.skinName = "TestSkin";
	}

	private _uiCompHandler(): void {
	}
}