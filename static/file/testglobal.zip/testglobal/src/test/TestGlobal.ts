class TestGlobal {

	public constructor() {}

	init():string{
		return "使用反射时，需要把这个类挂载到window对象才可使用";
	}

}

//需要将 TestGlobal 挂载到 window 对象中。
window["TestGlobal"] = TestGlobal;