var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var TestGlobal = (function () {
    function TestGlobal() {
    }
    TestGlobal.prototype.init = function () {
        return "使用反射时，需要把这个类挂载到window对象才可使用";
    };
    return TestGlobal;
}());
__reflect(TestGlobal.prototype, "TestGlobal");
//需要将 TestGlobal 挂载到 window 对象中。
window["TestGlobal"] = TestGlobal;
//# sourceMappingURL=TestGlobal.js.map