var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var TestCustom = (function (_super) {
    __extends(TestCustom, _super);
    function TestCustom() {
        var _this = _super.call(this) || this;
        _this._customSource = "mbtnGoods_png";
        _this.addEventListener(eui.UIEvent.CREATION_COMPLETE, _this._uiCompHandler, _this);
        _this.skinName = "TestCustomSkin";
        return _this;
    }
    TestCustom.prototype._uiCompHandler = function () {
        this.id_img.source = this._customSource;
    };
    return TestCustom;
}(eui.Component));
__reflect(TestCustom.prototype, "TestCustom");
//# sourceMappingURL=TestCustom.js.map